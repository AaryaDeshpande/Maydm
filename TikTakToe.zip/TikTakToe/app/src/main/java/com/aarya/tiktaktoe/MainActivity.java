package com.aarya.tiktaktoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button[][] buttons = new Button[3][3]; // the [3][3] makes it possible to have a 3 by 3 tik tak toe

    private boolean player1Turn = true; //player1Turn = player with the X

    private int roundCount;

    private int player1Points; // *keeps track* of player 1 points
    private int player2Points;

    private TextView textViewPlayer1; // this will *display* the points of player 1
    private TextView textViewPlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewPlayer1 = findViewById(R.id.text_view_p1);
        textViewPlayer2 = findViewById(R.id.text_view_p2);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }

        Button buttonReset = findViewById(R.id.button_reset);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (!((Button) v).getText().toString().equals("")) { // checks if a button that was clicked contains
            // an empty string. if this is not the case, it means that it was already used before (if there was already an X or O on this field) and skips the code
            // if there is something in a button, then it skips the below "else if"
            return; // skips this WHOLE method, so neither player can remark that spot
        }

        else if (player1Turn) { // checks if player 1 is true
            ((Button) v).setText("x"); // will only run if the button is empty, determined by above
        } else { // else meaning player 2's turn
            ((Button) v).setText("O"); // happens if !player1Turn is true
        }

        roundCount++;

        if (checkForWin()) { // this method is used to check if a win has taken place
            if (player1Turn) { // checks WHO won
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 9) { // this checks for a draw
            draw();
        } else {
            player1Turn = !player1Turn; // this switches turns
        }
    }

    private boolean checkForWin() { // this method will return either true or false
        String[][] field = new String[3][3]; // to check rows, columns and diagonals for win, we will save the text of our buttons in a [][] String array

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                field[i][j] = buttons[i][j].getText().toString(); // saves all buttons in this array
            }
        }

        // checks each of the three rows for a win
        for (int i = 0; i < 3; i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }

        // checks each of the three columns
        for (int i = 0; i < 3; i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }

        // these manually check the only two possible diagonals
        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;
        }

        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")) {
            return true;
        }

        return false;
    }

    private void player1Wins() {
        player1Points++;
        Toast.makeText(this, "Player 1  wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
    }

    private void player2Wins() {
        player2Points++;
        Toast.makeText(this, "Player 2  wins!", Toast.LENGTH_SHORT).show();
        updatePointsText();
        resetBoard();
    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void updatePointsText() {
        textViewPlayer1.setText("Player 1: " + player1Points);
        textViewPlayer2.setText("Player 2: " + player2Points);
    }

    private void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }

        roundCount = 0;
        player1Turn = true;
    }

    private void resetGame() {
        player1Points = 0;
        player2Points = 0;
        updatePointsText();
        resetBoard();
    }

    // this method saves the values below when the device is rotated
    @Override
    protected void onSaveInstanceState(Bundle outState) { // when device is rotated, this method will be called
        super.onSaveInstanceState(outState);               // and will save the below values

        outState.putInt("roundCount", roundCount);
        outState.putInt("player1Points", player1Points);
        outState.putInt("player2Points", player2Points);
        outState.putBoolean("player1Turn", player1Turn);
    }

    // this method reaches (gets) the above values into the app
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        roundCount = savedInstanceState.getInt("roundCount");
        player1Points =  savedInstanceState.getInt("player1Points");
        player2Points = savedInstanceState.getInt("player2Points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");
    }
}